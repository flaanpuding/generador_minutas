import os

BUCKET_ENTRADA = os.environ['BUCKET_ENTRADA']
BUCKET_SALIDA = os.environ['BUCKET_SALIDA']
